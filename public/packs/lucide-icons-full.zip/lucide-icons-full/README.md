# Finance OS — Complete Lucide icon set (static SVG)

Every icon Lucide publishes — the core library plus the experimental "Lab" set —
as raw SVGs. This is the full set 21st.dev surfaces under its Lucide family.

- **Total: 2713 SVGs**
  - `icons/` — **2356** core icons (`lucide-static` 1.72.0) — every canonical glyph + its aliases.
  - `lab/` — **357** experimental icons (`@lucide/lab` 0.13.0). These are unstable: Lucide may
    change, rename or graduate them into core. Kept in a separate folder for that reason.
- **Source:** https://lucide.dev · core `lucide-static`, lab `@lucide/lab`
- **Licence:** ISC for both — see `LICENSE`. Free to use, modify and redistribute with the notice.

> On the count: 21st.dev lists "2814" for Lucide, which over-counts the real library
> (it tallies some name variants more than once). The actual maximum — every distinct icon
> across core **and** lab — is **2713**, all included here.

## What's inside
- `icons/<name>.svg` / `lab/<name>.svg` — one file per icon, kebab-case. Each is a 24×24 stroke
  icon that inherits `currentColor`; set `width`/`height` and `stroke-width` to taste.

## Using these
- **In this React project, prefer `lucide-react`** (already a dependency):
  `import { Zap } from 'lucide-react'` — tree-shaken, coloured via `currentColor`, sized with props.
  For a lab icon, `import { Icon } from 'lucide-react'` + the node from `@lucide/lab`.
- **The raw SVGs are for everything outside React**: design tools (Figma, Sketch), email/HTML,
  documents, or build-time sprite generation.

## For motion
See the companion pack `animated-lucide-icons.zip` (AnimateIcons — animated Lucide components).
