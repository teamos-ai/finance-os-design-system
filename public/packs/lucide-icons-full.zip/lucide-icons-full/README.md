# Finance OS — Full Lucide icon set (static SVG)

The complete Lucide icon library as raw SVGs — every glyph in the design system's
icon family, in one place.

- **Source:** https://lucide.dev (npm package `lucide-static`)
- **Version:** 1.72.0
- **Icons:** 2356 SVG files (every glyph, aliases included)
- **Licence:** ISC — see `LICENSE`. Free to use, modify and redistribute with the notice.

## What's inside
- `icons/<name>.svg` — one file per icon, kebab-case (e.g. `arrow-right.svg`,
  `credit-card.svg`). Each is a 24×24 stroke icon that inherits `currentColor`;
  set `width`/`height` and `stroke-width` to taste.

## Using these
- **In this React project, prefer `lucide-react`** (already a dependency):
  `import { Zap } from 'lucide-react'` — tree-shaken, coloured via `currentColor`,
  sized with props. You rarely need the raw SVGs here.
- **The raw SVGs are for everything outside React**: design tools (Figma, Sketch),
  email/HTML, documents, or build-time sprite generation.

## For motion
See the companion pack `animated-lucide-icons.zip` (AnimateIcons, ~999 animated
Lucide components).
