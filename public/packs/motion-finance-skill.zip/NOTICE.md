# Notice

motion-finance is original work for the Finance OS brand. It vendors **no third-party code or
prose**. The fonts in `kit/assets/fonts` are Spline Sans and Anonymous Pro (SIL Open Font License).
The logos are Finance OS property.

Methods and conventions were informed by the open-source projects listed in
`skills/motion-finance/references/stack.md`, each under its own licence (Apache-2.0 / MIT).
HyperFrames (Apache-2.0) and GSAP are used as external tools, loaded at build time, not bundled.
