---
name: motion-finance
description: The Finance OS motion system — motion tokens, UI animation rules, and a HyperFrames pipeline for brand, explainer, data and social videos, with the signature Atlas Blue halftone-cloud texture. Use when adding or reviewing animation in a Finance OS interface (React, Framer Motion, CSS), when making any Finance OS video, motion graphic, animated diagram, logo sting or animated background, or when someone asks for "Finance OS motion", "motion-finance", a brand animation, or a halftone / pixel cloud background.
license: Proprietary — ONESTAAACK A.I PTY LTD. Third-party method credits in NOTICE.md.
metadata:
  version: 1.0.0
  brand: Finance OS
  design-system: https://ds.financeos.au/#motion
---

# motion-finance

Finance OS moves like the brand speaks: **calm, clear, grounded, authoritative**. Motion explains
and confirms; it never performs. One signature flourish — the **Atlas Blue halftone cloud** — is
the only place the brand shows off, and it is used once per piece.

## The five laws

1. **Land and hold.** Things arrive, settle, and stay still. Nothing drifts, breathes, floats or
   pulses once it has landed. (The cloud field is the one thing allowed a slow drift.)
2. **One move per moment.** At most two things in motion at once; one reveal per viewport band.
3. **Exits are quicker than entrances.** An exit is 40–50% shorter than the entrance it reverses.
4. **Nothing bounces.** No `back`, `elastic`, `bounce` or overshoot — except the single sanctioned
   **confirm** (a tick, a seal, a state flip), at most once per piece.
5. **Blue leads.** One Atlas Blue keyword per headline; motion points at it, never competes with it.

Reduced motion is not optional: every UI animation must degrade to its final state.

## Which path?

| The job | Read | Then |
| --- | --- | --- |
| Animate a Finance OS interface (hover, entrance, list, chart, number) | `references/tokens.md`, `references/ui-motion.md` | Use the tokens; verify in the browser |
| Make a video or motion graphic | `references/video.md`, `references/patterns.md` | Scaffold with `scripts/new-video.sh`, build, audit, render |
| Use the halftone clouds (web or video) | `references/clouds.md` | `kit/assets/fos-clouds.js` |
| Review existing motion | `references/qa.md` | Run `scripts/calm-audit.mjs` on compositions |
| Choose or justify tooling | `references/stack.md` | — |

## Tokens in one screen

| Token | Value | Use |
| --- | --- | --- |
| `fast` | 150 ms | hover, press, colour, focus |
| `base` | 250 ms | small state changes, exits |
| `slow` | 400 ms | the default entrance |
| `slower` | 600 ms | headlines, large surfaces |
| `draw` | 1200 ms | count-ups, chart lines |
| `ease-out` | `cubic-bezier(0.22, 1, 0.36, 1)` · GSAP `power3.out` | arrivals |
| `ease-in` | `cubic-bezier(0.55, 0, 1, 0.45)` · GSAP `power2.in` | exits |
| `ease-in-out` | `cubic-bezier(0.65, 0, 0.35, 1)` · GSAP `power2.inOut` | moves, layout, draw-on |
| `ease-confirm` | `cubic-bezier(0.34, 1.56, 0.64, 1)` · GSAP `back.out(1.6)` | the one sanctioned overshoot |
| `rise` | 8 / 12 / 24 px (UI) · 12 / 24 / 40 px (1080p video) | entrance travel |
| `stagger` | 40 ms tight · 70 ms base · cap the total at 500 ms | lists, grids, words |

Full table, CSS variables and the Framer Motion constants: `references/tokens.md`.

## Video workflow (HyperFrames)

```bash
# 1 · scaffold a branded composition (real fonts, real logos, tokens, clouds)
bash scripts/new-video.sh ./my-film

# 2 · write the film in my-film/index.html using the FOS helpers (references/patterns.md)

# 3 · gate it
cd my-film
HYPERFRAMES_NO_TELEMETRY=1 npx hyperframes lint
node ../scripts/calm-audit.mjs .          # brand + calm rules (path relative to where the skill lives)
HYPERFRAMES_NO_TELEMETRY=1 npx hyperframes snapshot --at 1,3,5   # open the contact sheet and LOOK

# 4 · render, then verify duration
HYPERFRAMES_NO_TELEMETRY=1 npx hyperframes render --quality looks --output out.mp4
ffprobe -v error -show_entries format=duration -of csv=p=0 out.mp4
```

Requires Node 22+ and FFmpeg. Do **not** run `hyperframes init` without `--skip-skills` (it
installs its own skills), and keep `HYPERFRAMES_NO_TELEMETRY=1` set.

## Hard rules (brand)

- **Logos: the provided assets only** — `kit/assets/logo-rect-blue.png`, `logo-square-blue.png`.
  Never draw, recolour, trace, animate the letterforms of, or generate a logo. Move the whole image.
- **Colour:** Atlas Blue `#33488F` is the only accent. No gold, no orange, no second hue in type.
- **Shape:** radius 2 / 4 / 6 / 8 px only. No pills. **No glassmorphism**, no backdrop blur panels.
- **No ribbons:** no accent side-rails, corner banners or edge strips — in stills or in motion.
- **Fonts:** Spline Sans (display + body) and Anonymous Pro (mono labels), from `kit/assets/fonts`.
- **Figures:** never animate a number the source did not state. Label sample data as sample.
- **Light only.** White canvas, or the blue sky. There is no dark theme.

## Before you call it done

- [ ] Every entrance lands and then holds; nothing loops.
- [ ] No banned ease; at most one confirm.
- [ ] One blue keyword per headline.
- [ ] UI: checked with `prefers-reduced-motion: reduce`; press and hover respond in ≤ 150 ms.
- [ ] Video: `lint` 0 errors, `calm-audit` 0 errors, contact sheet opened and read at full size,
      final line held ≥ 2 s, rendered duration equals `data-duration`.
