#!/usr/bin/env node
// calm-audit.mjs — the Finance OS brand + calm-motion gate for HyperFrames compositions.
//   node calm-audit.mjs <film-dir> [<film-dir> …]
// Reads index.html (and compositions/*.html). Exit 1 on any error. No dependencies.
import { readFileSync, existsSync, readdirSync } from 'node:fs'
import { join, basename } from 'node:path'

const dirs = process.argv.slice(2)
if (!dirs.length) { console.error('usage: calm-audit.mjs <film-dir> [...]'); process.exit(2) }

const strip = (s) => s.replace(/<!--[\s\S]*?-->/g, '').replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|[^:'"])\/\/.*$/gm, '$1')
let failed = false

for (const dir of dirs) {
  const files = [join(dir, 'index.html')]
  const sub = join(dir, 'compositions')
  if (existsSync(sub)) for (const f of readdirSync(sub)) if (f.endsWith('.html')) files.push(join(sub, f))
  const errors = [], warnings = []
  let src = ''
  for (const f of files) {
    if (!existsSync(f)) { errors.push(`missing ${f}`); continue }
    src += '\n' + strip(readFileSync(f, 'utf8'))
  }
  const count = (re) => (src.match(re) || []).length

  // — determinism —
  if (/Math\.random\s*\(/.test(src)) errors.push('unseeded Math.random() — frames must be a pure function of time')
  if (/Date\.now\s*\(|performance\.now\s*\(|new Date\s*\(\s*\)/.test(src)) errors.push('render-time clock (Date.now / performance.now)')
  if (/repeat\s*:\s*-1/.test(src)) errors.push('infinite repeat (repeat: -1) — nothing loops forever')
  if (/\btl\.play\s*\(/.test(src)) errors.push('tl.play() — the timeline must stay paused')
  if (/setTimeout\s*\(|setInterval\s*\(/.test(src)) errors.push('timers — drive everything from the timeline')

  // — calm —
  if (/elastic|bounce/i.test(src.replace(/no bounce|never bounce/gi, ''))) errors.push('banned ease: elastic / bounce')
  const overshoots = count(/back\.(out|inOut)|FOS\.confirm\s*\(/g)
  if (overshoots > 1) errors.push(`${overshoots} overshoots — the confirm is allowed once per film`)
  const froms = count(/\.from\s*\(/g), tos = count(/\btl\.to\s*\(|gsap\.to\s*\(/g)
  if (froms) warnings.push(`${froms}× .from() — use fromTo so every tween states both ends`)
  if (tos) warnings.push(`${tos}× .to() — use fromTo so every tween states both ends`)
  if (/backdrop-filter/.test(src)) warnings.push('backdrop-filter — no glassmorphism in the brand')

  // — pacing —
  const dur = Number((src.match(/id="root"[^>]*data-duration="([\d.]+)"/) || src.match(/data-duration="([\d.]+)"/) || [])[1] || 0)
  const scenes = count(/class="[^"]*\bclip\b[^"]*"/g)
  if (dur && scenes / dur > 0.5) warnings.push(`${scenes} clips in ${dur}s — a calm film stays under one cut every 2s`)

  // — brand —
  const logos = [...src.matchAll(/<img[^>]+src="([^"]*logo[^"]*)"/gi)].map((m) => m[1])
  for (const l of logos) if (!/logo-(rect|square)-blue\.png$/.test(l)) errors.push(`logo is not a provided asset: ${l}`)
  if (/<svg[^>]*(id|class)="[^"]*logo/i.test(src)) errors.push('an SVG is standing in for the logo — use the provided PNG')
  const offPalette = [...new Set((src.match(/#(?:F5A623|E8890C|EFB52B|D99A3E|FFA500|FFD700|E69500|F59E0B|FBBF24)\b/gi) || []))]
  if (offPalette.length) errors.push(`off-palette accent colour(s): ${offPalette.join(', ')} — Atlas Blue #33488F is the only accent`)
  for (const m of src.matchAll(/<h1[\s\S]*?<\/h1>/g)) {
    const n = (m[0].match(/class="[^"]*\bfos-hl\b/g) || []).length
    if (n > 1) errors.push(`${n} blue keywords in one headline — one per headline`)
  }
  if (/border-radius\s*:\s*(9999px|999px|50%|[1-9]\d{1,}px)/.test(src)) warnings.push('radius above 8px — the scale is 2 / 4 / 6 / 8')

  const name = basename(dir.replace(/\/$/, '')) || dir
  if (errors.length) failed = true
  console.log(`\n${errors.length ? '✗' : '✓'} ${name} — ${errors.length} error(s), ${warnings.length} warning(s)`)
  for (const e of errors) console.log(`   error   ${e}`)
  for (const w of warnings) console.log(`   warn    ${w}`)
}
process.exit(failed ? 1 : 0)
