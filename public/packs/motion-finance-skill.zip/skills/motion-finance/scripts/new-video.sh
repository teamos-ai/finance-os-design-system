#!/usr/bin/env bash
# new-video.sh — scaffold a branded Finance OS HyperFrames composition.
#   bash new-video.sh <target-dir>
set -euo pipefail
if [ $# -lt 1 ]; then echo "usage: new-video.sh <target-dir>" >&2; exit 2; fi
TARGET="$1"
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../kit" && pwd)"
if [ -e "$TARGET" ] && [ -n "$(ls -A "$TARGET" 2>/dev/null)" ]; then
  echo "refusing to overwrite: $TARGET is not empty" >&2; exit 1
fi
mkdir -p "$TARGET"
cp -R "$KIT/." "$TARGET/"
cat <<MSG
Scaffolded $TARGET
  index.html            the film — edit this
  assets/               fonts, logos, fos-brand.css, fos-motion.js, fos-clouds.js

Next:
  cd $TARGET
  HYPERFRAMES_NO_TELEMETRY=1 npx hyperframes lint
  HYPERFRAMES_NO_TELEMETRY=1 npx hyperframes snapshot --at 1,3
  HYPERFRAMES_NO_TELEMETRY=1 npx hyperframes render --quality looks --output out.mp4
MSG
