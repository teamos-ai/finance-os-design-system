# Halftone clouds — the signature texture

A procedurally drawn cloud field rendered as a halftone dot screen in Atlas Blue. It is the
brand's one expressive element: printed-paper calm, not sci-fi. It is code, not an image, so it
is always on-palette, resolution-independent, and animates without a video file.

`kit/assets/fos-clouds.js` — framework-free, deterministic (`FOSClouds.draw(ctx, w, h, t, opts)`).
The design system ships the same algorithm as `<HalftoneClouds>`.

## Two tones

| Tone | Ground | Ink | Use |
| --- | --- | --- | --- |
| `sky` | Atlas Blue gradient | white dots form the clouds | video backgrounds, hero bands, social cards, section dividers |
| `paper` | white | blue dots form the sky; clouds are the white gaps; fades down the frame | behind headlines, page tops, quiet UI backgrounds |

## Options

| Option | Default | Notes |
| --- | --- | --- |
| `shape` | `'dot'` | `'pixel'` gives a square, chunkier dither |
| `cell` | `9` | dot pitch in px. 6–8 fine, 9–12 standard, 14+ poster |
| `speed` | `0.02` | drift. 0.02 still-ish, 0.05 gentle, never above 0.08 |
| `reveal` | `1` | 0→1 runs the cloud dissolve |
| `seed` | `7` | a different sky |
| `fade` | `0.72` | `paper` only — where the ink has fully dissolved (0..1 of height) |

## Rules

- **Type never sits on dense dots.** On `sky`, put text on a white card. On `paper`, set `fade`
  so the ink is gone before the headline begins.
- **One field per view.** Never two cloud canvases visible together.
- **It drifts; it does not perform.** No speed changes, no zooms, no colour shifts.
- **The dissolve is the flourish** — once per film or page load, at the open or the close.
- **Blue and white only.** No tinted, gradient-ink or multi-colour variants.
- Web: pause when off-screen, cap near 24 fps, render a still frame under reduced motion.

## Web (React)

```tsx
<HalftoneClouds tone="paper" className="absolute inset-0" />
<HalftoneClouds tone="sky" cell={11} reveal className="h-64 rounded-lg" />
```

## Video

```html
<canvas id="sky" class="fos-clouds"></canvas>
```
```js
FOS.clouds(tl, '#sky', DURATION, { tone: 'sky', cell: 11, speed: 0.05, revealAt: 0.15 })
```

## Stills

For a static social card or slide background, snapshot a one-clip composition
(`npx hyperframes snapshot --at 2`) and use the PNG.
