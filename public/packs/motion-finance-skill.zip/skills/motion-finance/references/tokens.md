# Motion tokens

One vocabulary across CSS, Framer Motion and GSAP. If a value is not in this table, it is not
part of the brand — add a token before you add a magic number.

## Duration

| Token | CSS variable | Seconds | Use |
| --- | --- | --- | --- |
| fast | `--dur-fast` | 0.15 | hover, press, colour, focus ring, tooltip |
| base | `--dur-base` | 0.25 | small state change, **exit**, popover |
| slow | `--dur-slow` | 0.40 | the default entrance (rise-in) |
| slower | `--dur-slower` | 0.60 | headline mask reveal, large surface, hero |
| draw | `--dur-draw` | 1.20 | count-up, chart line draw-on, progress |

A single entrance never exceeds 800 ms. High-frequency interactions (anything a user does dozens
of times a session) get `fast` and animate **opacity or colour only**.

## Easing — chosen by role, never by taste

| Role | CSS variable | Curve | Framer Motion | GSAP |
| --- | --- | --- | --- | --- |
| Arrive | `--ease-out` | `cubic-bezier(0.22, 1, 0.36, 1)` | `[0.22, 1, 0.36, 1]` | `power3.out` |
| Leave | `--ease-in` | `cubic-bezier(0.55, 0, 1, 0.45)` | `[0.55, 0, 1, 0.45]` | `power2.in` |
| Move / draw | `--ease-in-out` | `cubic-bezier(0.65, 0, 0.35, 1)` | `[0.65, 0, 0.35, 1]` | `power2.inOut` |
| Numbers | — | ease-out-expo | cubic ease-out in `CountUp` | `expo.out` |
| Confirm | `--ease-confirm` (alias `--ease-spring`) | `cubic-bezier(0.34, 1.56, 0.64, 1)` | same | `back.out(1.6)` |
| Constant | — | `linear` | `'linear'` | `none` |

`linear` is only for things that represent continuous travel: a marquee, a pulse along a wire,
the cloud drift, a slow push-in.

## Distance

| Token | CSS variable | UI | 1080p video |
| --- | --- | --- | --- |
| rise-sm | `--rise-sm` | 8 px | 12 px |
| rise | `--rise` | 12 px | 24 px |
| rise-lg | `--rise-lg` | 24 px | 40 px |

Entrances rise (travel **up** into place). Exits continue upward by `rise-sm`. One dominant
direction per page or film.

## Stagger

| Token | CSS variable | Value | Use |
| --- | --- | --- | --- |
| stagger-tight | `--stagger-tight` | 40 ms | dense lists, table rows, chips |
| stagger | `--stagger` | 70 ms | cards, grid cells |
| words | — | 80 ms | per word / per line in a headline |

Cap the **total** stagger at 500 ms: for a long list, stagger the first 6–7 items and let the
rest arrive together.

## Other constants

- Press: `scale(0.97)`, `fast`. Never below 0.95.
- Hover lift: `translateY(-2px)` to `-4px`, `base`, with a shadow step up.
- Blur-in: `blur(6px) → 0` paired with the rise, for single hero blocks only.
- Blur swap (content change): out 160 ms with 8 px blur, in 240 ms, overlapping by 20 ms.
- Read-hold in video: 0.5 s + 0.3 s per word; the final line holds ≥ 2 s.
- Camera: one slow push-in per film, ≤ 1.06×, linear.

## In code

```css
/* CSS — tokens.css */
transition: opacity var(--dur-fast) var(--ease-out), transform var(--dur-fast) var(--ease-out);
```

```tsx
// Framer Motion — src/lib/motion-tokens.ts in the design system
import { MOTION } from '@/lib/motion-tokens'
<motion.div
  initial={{ opacity: 0, y: MOTION.rise.md }}
  whileInView={{ opacity: 1, y: 0 }}
  transition={{ duration: MOTION.dur.slow, ease: MOTION.ease.out }}
/>
```

```js
// GSAP / HyperFrames — kit/assets/fos-motion.js
FOS.rise(tl, '#card', 1.2)              // slow · power3.out · 24px
FOS.countUp(tl, '#stat', 2713, 1.6)     // draw · expo.out
```
