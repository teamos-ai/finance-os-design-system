# Pattern library

Eleven moves. If a film or screen needs something not on this list, question the need first.
Each has a `FOS.*` helper in `kit/assets/fos-motion.js` (video) and a primitive in the design
system's `src/lib/motion.tsx` (web). Working films: `examples/`.

| # | Pattern | Video helper | Web primitive | Example |
| --- | --- | --- | --- | --- |
| 1 | Rise-in | `FOS.rise` | `FadeIn` | all |
| 2 | Stagger | `FOS.rise(…, { stagger })` | `Stagger` | data-story, flow-diagram |
| 3 | Masked headline, one blue keyword | `FOS.maskLines` | `MaskReveal` | kinetic-headline |
| 4 | Drawn underline / line draw-on | `FOS.draw` | `DrawLine` | kinetic-headline |
| 5 | Count-up stat | `FOS.countUp` | `CountUp` | data-story |
| 6 | Bars from the baseline | `FOS.grow` | CSS `scaleY` + `origin-bottom` | data-story |
| 7 | Diagram build (5 acts) | `FOS.rise` + `FOS.draw` | — | flow-diagram |
| 8 | Blur swap | `FOS.swap` | `AnimatePresence` + blur | — |
| 9 | Confirm (the one overshoot) | `FOS.confirm` | `ease-confirm` | flow-diagram |
| 10 | Slow push-in | `FOS.push` | — | — |
| 11 | **Cloud dissolve** (signature) | `FOS.clouds(…, { revealAt })` | `HalftoneClouds` | brand-sting |

## 1 · Rise-in
```js
FOS.rise(tl, '#card', 1.2)                       // 0.4s, 24px, power3.out
FOS.rise(tl, '#eyebrow', 0.3, { y: FOS.rise.sm })
```
The default. Use it for almost everything; variety comes from order and timing, not from effects.

## 3 · Masked headline
```html
<h1 id="h" class="fos-headline">
  <span class="fos-line"><span class="fos-line__in">More <span class="fos-hl">settlements</span>.</span></span>
  <span class="fos-line"><span class="fos-line__in">Less admin.</span></span>
</h1>
```
```js
FOS.maskLines(tl, '#h', 0.5)          // each line slides up from behind its mask
```
One `.fos-hl` per headline. Break lines by sense, one idea per line.

## 4 · Drawn underline
An SVG path under the keyword, drawn **after** the line lands (never during):
```js
FOS.draw(tl, '#underline-path', 1.75, { duration: 0.55 })
```

## 5 · Count-up
```js
FOS.countUp(tl, '#n', 2713, 1.6)                                  // integers, en-AU grouping
FOS.countUp(tl, '#pct', 96, 1.6, { format: v => v.toFixed(0) + '%' })
```
The card lands first; the number runs next. Give the element `class="fos-num"` (tabular numerals).
Only real figures; cite the source in the storyboard ledger.

## 6 · Bars from the baseline
Bars are real-height blocks; the helper scales them from the bottom. Labels arrive after.
```js
FOS.grow(tl, '.bar', 3.5, { stagger: 0.12 })
FOS.rise(tl, '.bar-label', 4.2, { y: FOS.rise.sm, stagger: 0.12 })
```
Direct labels, no legend, no gridlines, no pie charts.

## 7 · Diagram build — five acts
1. **Establish** (0–1 s): title.
2. **Build:** nodes rise in reading order (0.5 s each, 0.1 s apart).
3. **Connect:** each edge draws (0.45 s), then its arrowhead arrives (0.22 s) — the arrowhead is a
   separate element inside a positioning `<g>`.
4. **Flow:** one pulse travels the chain once, linear.
5. **Resolve:** the outcome is marked (border to blue, a confirm tick), then hold ≥ 1 s.

At most two things moving at once. No camera for six nodes or fewer.

## 9 · Confirm
```js
FOS.confirm(tl, '#tick', 5.6)        // back.out(1.6), 0.36s — once per film
```

## 11 · Cloud dissolve (the signature flourish)
```js
FOS.clouds(tl, '#sky', 7, { tone: 'sky', cell: 11, speed: 0.05, revealAt: 0.15, revealDur: 1.7 })
```
The halftone field blooms in dot by dot. **Once per piece**, as the opening or the close.
Without `revealAt` the field is simply present and drifting — fine as a background any time.
See `clouds.md`.

## Recipes (films)

| Film | Length | Beats |
| --- | --- | --- |
| Brand sting | 5–7 s | cloud dissolve → lockup card lands → tagline mask → hold |
| Kinetic headline | 5–6 s | chip → 2–3 masked lines → underline on the keyword → one body line → hold |
| Data story | 6–10 s | title → stat cards → count-ups → bars → labels → hold |
| Flow explainer | 8–12 s | title → nodes → edges → pulse → resolve → hold |
| Feature reveal | 8–15 s | headline → UI card rises → 1–2 blur swaps inside it → push-in → hold |
