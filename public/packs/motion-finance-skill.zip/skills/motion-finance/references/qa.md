# Review and QA

## The calm audit (automated)

```bash
node scripts/calm-audit.mjs <film-dir> [<film-dir> …]
```

Errors (exit 1): banned eases (`elastic`, `bounce`), more than one overshoot, infinite repeats,
render-time clocks or unseeded randomness, `tl.play()`, a logo that is not the provided asset,
an off-palette accent colour (gold / orange), more than one blue keyword in a headline.
Warnings: `gsap.from`/`.to` instead of `fromTo`, more than one cut every 2 s, backdrop blur.

## Manual checks — video

1. Contact sheet: one frame per beat. Does each frame read on its own?
2. One full-size frame per scene: type size, safe box, overlaps, contrast.
3. Frames at ±0.1 s around every transition: no flash, no half-state.
4. Watch the render once at full speed with fresh eyes, then once at 0.25×.
5. Last line held ≥ 2 s. Duration matches `data-duration`.
6. Every figure traced to its source. Sample data labelled.

## Manual checks — UI

1. Reduced motion on: everything visible, nothing animates.
2. Keyboard: focus rings appear instantly (no transition delay on focus).
3. 10% speed: no competing motion, exits shorter than entrances, nothing loops.
4. Phone width: tall blocks still reveal (in-view margin, not a fraction threshold).
5. Throttle CPU 4×: no dropped-frame stutter on scroll; canvases pause off-screen.

## Named failures

| Name | Looks like | Fix |
| --- | --- | --- |
| Slideshow | everything arrives at once, then a frozen frame | order the arrivals; overlap 30–50% |
| Screensaver | something drifts or pulses forever | land and hold |
| Consumer sting | bouncy entrances on a B2B film | `power3.out`; keep the one confirm |
| PowerPoint with voiceover | every scene laid out fresh with fade-ups | carry one element across the cut |
| Confetti | three accents, four eases, five directions | one accent, eases by role, one direction |
