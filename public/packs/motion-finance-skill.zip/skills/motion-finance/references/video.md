# Video pipeline (HyperFrames)

Finance OS videos are HTML + a paused GSAP timeline, rendered frame-by-frame to MP4 by
[HyperFrames](https://github.com/heygen-com/hyperframes). Deterministic: the same file always
renders the same pixels.

## 0 · Before you write a frame

Write three things in the film's `README.md` or at the top of `index.html`:

1. **Tone sentence** — e.g. "A calm 7-second sting: the sky arrives, the name lands, we hold."
2. **Storyboard ledger** — one row per beat: time · what is on screen · what moves · source of
   any claim or figure. **No figure without a source.** Sample data is labelled as sample.
3. **The one flourish** — where (if anywhere) the cloud dissolve is used. Once.

## 1 · Scaffold

```bash
bash scripts/new-video.sh ./my-film      # copies kit/ → my-film/
```

You get `index.html` (a working branded title card) and `assets/` (fonts, logos, `fos-brand.css`,
`fos-motion.js`, `fos-clouds.js`). Formats: 1920×1080 (default), 1080×1920 vertical, 1080×1080
square — change `data-width` / `data-height` and the viewport meta together.

## 2 · Composition contract (the parts that bite)

- One root: `<div id="root" data-composition-id="main" data-width data-height data-duration>`.
- Timed elements: `class="clip"` + `data-start` + `data-duration` (seconds).
- Exactly one `gsap.timeline({ paused: true })`, registered **after** it is built:
  `window.__timelines['main'] = tl`. Never call `tl.play()`.
- **`fromTo` only** (the FOS helpers do this). Never a CSS `transform` on an element GSAP transforms.
- Never tween `opacity`-adjacent visibility (`display`, `visibility`, `autoAlpha`) on a `.clip` —
  animate a child.
- **No** `Date.now()`, `performance.now()`, unseeded `Math.random()`, timers, network fetches,
  or `repeat: -1`.
- `@font-face` rules stay **inline** in `index.html` (the linter requires it).
- Keep content inside `.fos-safe` (the 90% action-safe box).
- An SVG `<g>` that holds a position must not be the tween target — animate its child.

## 3 · Motion grammar for film

| Beat | Duration | Ease |
| --- | --- | --- |
| Element entrance | 0.3–0.5 s | `power3.out` |
| Headline mask reveal | 0.6 s, lines 0.09–0.14 s apart | `power3.out` |
| Exit | 0.2–0.25 s | `power2.in` |
| Count-up | 1.2 s | `expo.out` |
| Line / edge draw-on | 0.45–1.2 s | `power1.inOut` / `power2.inOut` |
| Bar grow | 0.6 s, 0.12 s apart | `power3.out` |
| Pulse along a wire | 0.9–1.6 s | `none` |
| Cloud dissolve | 1.4–1.8 s | `power2.inOut` |
| Push-in | whole scene, ≤ 1.06× | `none` |

- **Pacing:** calm films hold 2–4 s per idea and stay under one cut every 2 s.
- **Overlap:** the next element starts when the previous is 30–50% through its entrance.
- **Pause before the payoff:** 0.3–0.75 s of stillness before the key number or line.
- **Outro:** the last frame holds ≥ 2 s (4–6 s if it carries a call to action).
- **Two failure modes:** *Slideshow* (everything dumps in, then freezes) and *Screensaver*
  (something drifts forever). Aim between: arrive in order, then be still.

## 4 · Gate

```bash
HYPERFRAMES_NO_TELEMETRY=1 npx hyperframes lint          # 0 errors
node <skill>/scripts/calm-audit.mjs .                    # 0 errors
HYPERFRAMES_NO_TELEMETRY=1 npx hyperframes snapshot --at <one time per beat>
```

Open the contact sheet **and at least one full-size frame**. Check: text inside the safe box,
nothing overlapping, the blue keyword is the only blue word in its headline, type ≥ 22 px.

The linter's `nested_structure_needs_subcomposition` warning is expected for single-file films;
split into `compositions/*.html` only when a film grows past ~4 scenes.

## 5 · Render and verify

```bash
HYPERFRAMES_NO_TELEMETRY=1 npx hyperframes render --quality looks --output out.mp4
ffprobe -v error -show_entries format=duration -of csv=p=0 out.mp4   # must equal data-duration
```

Delivery: `--quality delivery`. Web embed copy (small):

```bash
ffmpeg -i out.mp4 -vf scale=1280:-2 -c:v libx264 -crf 26 -preset slow -pix_fmt yuv420p -movflags +faststart -an web.mp4
ffmpeg -ss 5 -i out.mp4 -frames:v 1 -vf scale=1280:-2 -q:v 3 poster.jpg
```

## Sound

Out of scope for v1. When music is added: cuts land on bar lines (not every beat), mix to about
−15 LUFS, fade in 0.3 s and out 1 s. Beat grids can be extracted offline with librosa; nothing
audio-related ships in an app bundle.
