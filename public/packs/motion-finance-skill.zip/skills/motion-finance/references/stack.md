# Stack and sources

What motion-finance depends on, what it only learned from, and what was rejected — with reasons,
so the choice can be revisited deliberately.

## Depend on

| Layer | Tool | Why |
| --- | --- | --- |
| UI motion | Framer Motion + CSS custom properties | already in the design system; interruptible; no new weight |
| Video | HyperFrames (`npx hyperframes`, Apache-2.0) + GSAP | HTML/CSS we already write; deterministic frame-accurate renders; no second design language |
| Encode | FFmpeg | web copies, posters, format changes |
| Texture | `fos-clouds.js` (ours, ~150 lines) | on-palette by construction; no asset pipeline |

## Add only when a real need appears

| Tool | Trigger | Note |
| --- | --- | --- |
| three.js + @react-three/fiber | the first genuinely 3D chart or product shot | lazy-load; mind React de-duping in the design system's Vite config |
| postprocessing | only inside a three.js scene | grain / vignette; no bloom on white |
| librosa (offline, via `uv`) | the first film cut to music | outputs a `beats.json`; never ships in an app |
| Tegaki (MIT) | a handwritten signature or annotation | one per piece |

## Learned from (method only — nothing vendored)

| Source | Licence | What was taken |
| --- | --- | --- |
| heygen-com/hyperframes skills | Apache-2.0 | composition contract, CLI loop, ease-by-role, read-hold timings, banned idle loops |
| jakubkrehel/make-interfaces-feel-better | MIT | CSS-transitions-for-state, staged enter/exit numbers, press scale, never `transition: all` |
| alchaincyf/huashu-design | MIT | camera budget, pause-before-payoff, export specs |
| AbubakrChan/product-launch-motion | MIT | "nothing ends moving", rationed overshoot, contact-sheet QA, Slideshow / Screensaver |
| omkamal/animated-diagrams-skill | Apache-2.0 | five-act diagram build, separate arrowheads, two-thread limit |
| nutllwhy/hyperframes-motion-library | MIT | per-template contract, no unsourced numbers, chart draw timings |
| tugrawork-creator/saas-motion-kit | MIT | tone matrix, storyboard ledger, calm-film audit thresholds |
| gongnyang/reelforge | Apache-2.0 | "what is not verified is not vocabulary" |
| Vincentwei1021/video-shotcraft | Apache-2.0 | shot-recipe idea, beat-sync method (for later) |
| patch-gg/pixelfx | MIT | palette-ramp pixel simulation idea behind the clouds |

## Rejected

| Option | Why |
| --- | --- |
| Remotion | a second renderer and a company licence to manage; HyperFrames covers the need |
| Blender MCP | a whole toolchain for output reachable in SVG/three.js |
| react-three-rapier (physics) | reads playful; not frame-deterministic |
| Mascot / character kits | off-brand |
| Style prompt packs (incl. lemo-opuscar's CC BY-NC styles) | off-brand or non-commercial; read for structure only |
| Generated people / AI footage in motion pieces | use the real photo library |
