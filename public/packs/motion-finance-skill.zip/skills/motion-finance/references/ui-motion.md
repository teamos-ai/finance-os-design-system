# UI motion (React · Framer Motion · CSS)

Rules for interfaces. Numbers come from `tokens.md`.

## Decide first: does this need to move?

Motion earns its place when it does one of three jobs:
- **Orient** — show where something came from or went (a panel opening from its trigger).
- **Confirm** — acknowledge an action (press, saved, copied).
- **Pace** — reveal content in reading order so the eye is led, not flooded.

If it does none of these, it is decoration. Cut it.

## Rules

1. **CSS transitions for interactive state** (hover, press, focus, open/closed) — they are
   interruptible. Keyframes or Framer `animate` only for one-shot sequences.
2. **Never `transition: all`.** Name the properties. Animate `transform`, `opacity`, `filter`;
   colour and shadow are fine at `fast`. Do not animate `width`/`height`/`top`/`left` for motion.
3. **Entrance:** `opacity 0 → 1` + `y: rise → 0`, `slow`, `ease-out`, once, when ~10% into view.
   Use an in-view margin, not a visible-fraction threshold, so tall blocks on phones still trigger.
4. **One reveal per viewport band.** A section header reveals; its grid staggers; nothing else.
5. **Stagger** `stagger` (70 ms), total capped at 500 ms.
6. **Exit:** `base`, `ease-in`, `y: -8`. Elements with a default state use
   `<AnimatePresence initial={false}>` so they do not animate on first paint.
7. **Press:** `active:scale-[0.97]`, `fast`. **Hover:** colour/shadow at `fast`; a lift is `base`.
8. **Numbers:** tabular numerals, count up once on first view, `draw`, no overshoot.
9. **Charts:** lines draw on (`draw`, `ease-in-out`); bars grow from the baseline (`slower`,
   `ease-out`, staggered); the end value or label appears last.
10. **No idle loops** on content. Sanctioned loops: marquee, a status `BreathingDot`, the cloud
    field, and the hero mark's float (a deliberate, documented exception).
11. **Reduced motion:** every primitive checks `useReducedMotion()` and renders the final state;
    the global CSS guard zeroes transitions. Test it.
12. **Performance:** `will-change` only on `transform`/`opacity`/`filter` and only while animating.
    Canvas backgrounds pause when off-screen and cap at ~24 fps.

## The primitives (design system `src/lib/motion.tsx`)

| Primitive | What it does |
| --- | --- |
| `FadeIn` | the standard rise-in entrance |
| `Stagger` / `StaggerItem` | a grid or list arriving in order |
| `Reveal` | rise + blur-in for one hero block |
| `MaskReveal` | headline lines sliding up from a mask |
| `CountUp` | a number running to its value |
| `DrawLine` | an SVG path drawing on |
| `HoverLift` | calm hover raise |
| `HalftoneClouds` | the signature canvas texture |

## Review at 10% speed

Slow the animation right down (DevTools → Animations) and watch for: two things fighting for
attention, an exit slower than its entrance, anything that keeps moving, a jump at the end.
