/*!
 * fos-motion.js — the Finance OS motion tokens and presets for GSAP / HyperFrames.
 *
 * One vocabulary, the same numbers the design system uses in the browser (see references/tokens.md).
 * Every helper adds `fromTo` tweens to a paused timeline at an absolute time, so a composition
 * stays seekable and deterministic.
 *
 *   const tl = gsap.timeline({ paused: true })
 *   FOS.rise(tl, '#title', 0.4)
 *   FOS.countUp(tl, '#stat', 21, 1.2)
 */
(function (root) {
  'use strict'

  var FOS = {
    /** seconds */
    dur: { fast: 0.15, base: 0.25, slow: 0.4, slower: 0.6, draw: 1.2, hold: 2 },
    /** GSAP ease names, by ROLE — never pick an ease by taste */
    ease: {
      enter: 'power3.out', // arrivals: fast in, soft landing
      exit: 'power2.in', // departures: shorter than the entrance
      move: 'power2.inOut', // camera, layout, colour floods
      count: 'expo.out', // numbers
      draw: 'power2.inOut', // lines, strokes
      confirm: 'back.out(1.6)', // the ONE sanctioned overshoot: a tick, a seal, a state flip
      linear: 'none',
    },
    /** px at 1920×1080 */
    rise: { sm: 12, md: 24, lg: 40 },
    stagger: { tight: 0.04, base: 0.07, words: 0.08 },
    color: {
      blue: '#33488F', blue300: '#5C6DA5', blue500: '#1F2B56', blue50: '#EEF2F9',
      ink: '#14161B', muted: '#474E5C', subtle: '#646C7D',
      canvas: '#FFFFFF', warm: '#E8EDF7', border: '#E6E8EC',
    },
  }

  /** Rise-in: opacity + a small upward travel. The default entrance. */
  FOS.rise = function (tl, target, at, opts) {
    var o = opts || {}
    tl.fromTo(
      target,
      { opacity: 0, y: o.y == null ? FOS.rise.md : o.y },
      { opacity: 1, y: 0, duration: o.duration || FOS.dur.slow, ease: FOS.ease.enter, stagger: o.stagger || 0 },
      at,
    )
    return tl
  }
  FOS.rise.sm = 12
  FOS.rise.md = 24
  FOS.rise.lg = 40

  /** Exit: quicker than the entrance, a short upward drift. */
  FOS.exit = function (tl, target, at, opts) {
    var o = opts || {}
    tl.fromTo(
      target,
      { opacity: 1, y: 0 },
      { opacity: 0, y: o.y == null ? -12 : o.y, duration: o.duration || FOS.dur.base, ease: FOS.ease.exit, stagger: o.stagger || 0 },
      at,
    )
    return tl
  }

  /**
   * Masked line reveal — the headline entrance. Each `.fos-line` must be an overflow:hidden block
   * wrapping one `.fos-line__in` block; the inner block slides up from below the mask.
   */
  FOS.maskLines = function (tl, container, at, opts) {
    var o = opts || {}
    var inner = (typeof container === 'string' ? document.querySelector(container) : container).querySelectorAll('.fos-line__in')
    tl.fromTo(
      inner,
      { yPercent: 108 },
      { yPercent: 0, duration: o.duration || FOS.dur.slower, ease: FOS.ease.enter, stagger: o.stagger == null ? 0.09 : o.stagger },
      at,
    )
    return tl
  }

  /** Count-up: tabular numerals, no overshoot. `format` receives the current number. */
  FOS.countUp = function (tl, target, to, at, opts) {
    var o = opts || {}
    var el = typeof target === 'string' ? document.querySelector(target) : target
    var state = { v: o.from || 0 }
    var fmt = o.format || function (v) { return Math.round(v).toLocaleString('en-AU') }
    el.textContent = fmt(state.v)
    tl.fromTo(
      state,
      { v: o.from || 0 },
      {
        v: to,
        duration: o.duration || FOS.dur.draw,
        ease: FOS.ease.count,
        onUpdate: function () { el.textContent = fmt(state.v) },
      },
      at,
    )
    return tl
  }

  /** Draw-on for an SVG path / line / polyline (stroke-dashoffset). */
  FOS.draw = function (tl, target, at, opts) {
    var o = opts || {}
    var els = typeof target === 'string' ? document.querySelectorAll(target) : target.length != null ? target : [target]
    Array.prototype.forEach.call(els, function (el, i) {
      var len = el.getTotalLength()
      el.style.strokeDasharray = len
      tl.fromTo(
        el,
        { strokeDashoffset: len },
        { strokeDashoffset: 0, duration: o.duration || FOS.dur.draw, ease: o.ease || FOS.ease.draw },
        at + i * (o.stagger || 0),
      )
    })
    return tl
  }

  /** Bars grow from their baseline. Elements need transform-origin at the baseline. */
  FOS.grow = function (tl, target, at, opts) {
    var o = opts || {}
    tl.fromTo(
      target,
      { scaleY: 0 },
      { scaleY: 1, duration: o.duration || FOS.dur.slower, ease: FOS.ease.enter, stagger: o.stagger == null ? FOS.stagger.base : o.stagger, transformOrigin: '50% 100%' },
      at,
    )
    return tl
  }

  /** Blur swap: the content change. Old out fast, new in soft. */
  FOS.swap = function (tl, outTarget, inTarget, at) {
    tl.fromTo(outTarget, { opacity: 1, filter: 'blur(0px)' }, { opacity: 0, filter: 'blur(8px)', duration: 0.16, ease: FOS.ease.exit }, at)
    tl.fromTo(inTarget, { opacity: 0, filter: 'blur(8px)' }, { opacity: 1, filter: 'blur(0px)', duration: 0.24, ease: FOS.ease.enter }, at + 0.14)
    return tl
  }

  /** Confirm: the one place an overshoot is allowed (ticks, seals, state flips). */
  FOS.confirm = function (tl, target, at) {
    tl.fromTo(target, { opacity: 0, scale: 0.6 }, { opacity: 1, scale: 1, duration: 0.36, ease: FOS.ease.confirm }, at)
    return tl
  }

  /** Slow push-in on a wrapper — the only camera move. Max 1.06× for a calm film. */
  FOS.push = function (tl, target, at, duration, scale) {
    tl.fromTo(target, { scale: 1 }, { scale: scale || 1.04, duration: duration, ease: FOS.ease.linear, transformOrigin: '50% 50%' }, at)
    return tl
  }

  /**
   * Halftone clouds on a canvas, driven by the timeline (so every frame is seekable).
   * `revealAt` / `revealDur` run the cloud-dissolve flourish; omit them for a field that is simply there.
   */
  FOS.clouds = function (tl, canvas, total, opts) {
    var o = opts || {}
    var el = typeof canvas === 'string' ? document.querySelector(canvas) : canvas
    var w = o.width || 1920, h = o.height || 1080
    var ctx = root.FOSClouds.fit(el, w, h, 1)
    var state = { t: 0, reveal: o.revealAt == null ? 1 : 0 }
    var paint = function () {
      root.FOSClouds.draw(ctx, w, h, state.t, {
        tone: o.tone, shape: o.shape, cell: o.cell, speed: o.speed, seed: o.seed, fade: o.fade, colors: o.colors, reveal: state.reveal,
      })
    }
    paint()
    tl.fromTo(state, { t: 0 }, { t: total, duration: total, ease: 'none', onUpdate: paint }, 0)
    if (o.revealAt != null) {
      tl.fromTo(state, { reveal: 0 }, { reveal: 1, duration: o.revealDur || 1.4, ease: FOS.ease.move, onUpdate: paint }, o.revealAt)
    }
    return tl
  }

  root.FOS = FOS
})(typeof window !== 'undefined' ? window : globalThis)
