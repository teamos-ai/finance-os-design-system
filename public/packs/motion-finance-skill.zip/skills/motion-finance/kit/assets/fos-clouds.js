/*!
 * fos-clouds.js — the Finance OS signature texture: Atlas Blue halftone clouds.
 *
 * Framework-free and deterministic: every frame is a pure function of (time, options), so it is
 * safe inside a HyperFrames render (no clocks, no Math.random) and inside a React canvas.
 *
 *   FOSClouds.draw(ctx, width, height, time, options)
 *
 * options
 *   tone    'sky'   blue ground, white halftone clouds (video / hero / social)
 *           'paper' white ground, blue halftone sky that dissolves down the page (UI backgrounds)
 *   shape   'dot' (halftone) | 'pixel' (square dither)
 *   cell    grid pitch in px (default 9). Bigger = chunkier.
 *   speed   drift in noise-units per second (default 0.02 — a slow, calm drift)
 *   reveal  0..1 — the "cloud dissolve" flourish: dots bloom in noise order as it runs 0 → 1
 *   seed    integer; changes the cloud field
 *   fade    'paper' only: 0..1 of the height at which the ink has fully dissolved (default 0.72)
 *   colors  { ground0, ground1, ink } — pass brand tokens; defaults are the Atlas Blue ramp
 */
(function (root) {
  'use strict'

  function hash(x, y, seed) {
    var h = (Math.imul(x, 374761393) + Math.imul(y, 668265263) + Math.imul(seed, 1442695041)) | 0
    h = Math.imul(h ^ (h >>> 13), 1274126177)
    return ((h ^ (h >>> 16)) >>> 0) / 4294967295
  }
  function vnoise(x, y, seed) {
    var xi = Math.floor(x), yi = Math.floor(y)
    var xf = x - xi, yf = y - yi
    var u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf)
    var a = hash(xi, yi, seed), b = hash(xi + 1, yi, seed)
    var c = hash(xi, yi + 1, seed), d = hash(xi + 1, yi + 1, seed)
    return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v
  }
  function fbm(x, y, seed) {
    var s = 0, a = 0.5, f = 1
    for (var i = 0; i < 4; i++) {
      s += a * vnoise(x * f, y * f, seed + i * 17)
      f *= 2.02
      a *= 0.5
    }
    return s / 0.9375
  }
  function smooth(a, b, x) {
    var t = Math.min(1, Math.max(0, (x - a) / (b - a)))
    return t * t * (3 - 2 * t)
  }

  /** Cloud density 0..1 at normalised coords (nx across, ny down), at time t (seconds). */
  function density(nx, ny, aspect, t, speed, seed) {
    // clouds are wider than tall: stretch x, and drift slowly to the right
    var n = fbm(nx * 2.1 * aspect - t * speed, ny * 3.1, seed)
    // a second, slower layer gives the billow its soft shoulders
    var m = fbm(nx * 1.1 * aspect - t * speed * 0.6 + 40, ny * 1.7 + 9, seed + 101)
    return smooth(0.44, 0.74, n * 0.72 + m * 0.34)
  }

  var DEFAULTS = {
    tone: 'sky',
    shape: 'dot',
    cell: 9,
    speed: 0.02,
    reveal: 1,
    seed: 7,
    fade: 0.72,
    colors: null,
  }
  var PALETTE = {
    sky: { ground0: '#33488F', ground1: '#5C6DA5', ink: '#FFFFFF' },
    paper: { ground0: '#FFFFFF', ground1: '#FFFFFF', ink: '#33488F' },
  }

  function draw(ctx, w, h, time, options) {
    var o = {}
    for (var k in DEFAULTS) o[k] = options && options[k] != null ? options[k] : DEFAULTS[k]
    var pal = o.colors || PALETTE[o.tone] || PALETTE.sky
    var cell = Math.max(3, o.cell)
    var aspect = w / h
    var paper = o.tone === 'paper'

    // ground
    if (pal.ground0 === pal.ground1) {
      ctx.fillStyle = pal.ground0
    } else {
      var g = ctx.createLinearGradient(0, 0, 0, h)
      g.addColorStop(0, pal.ground0)
      g.addColorStop(1, pal.ground1)
      ctx.fillStyle = g
    }
    ctx.fillRect(0, 0, w, h)

    // ink
    ctx.fillStyle = pal.ink
    ctx.beginPath()
    var cols = Math.ceil(w / cell) + 1, rows = Math.ceil(h / cell) + 1
    var half = cell / 2
    for (var j = 0; j < rows; j++) {
      // classic halftone: every other row is offset half a cell
      var off = o.shape === 'dot' && j % 2 ? half : 0
      for (var i = 0; i < cols; i++) {
        var cx = i * cell + off, cy = j * cell
        var nx = cx / w, ny = cy / h
        var d = density(nx, ny, aspect, time, o.speed, o.seed)
        var a
        if (paper) {
          // ink is the SKY; clouds are the white gaps. Fades out down the page.
          a = (1 - d) * 0.6 * (1 - smooth(0.08, o.fade == null ? 0.72 : o.fade, ny))
        } else {
          // ink is the CLOUD, over a faint dither in the open sky
          a = 0.035 + d * 0.9
        }
        if (o.reveal < 1) {
          // cloud dissolve: each dot has its own threshold, so the field blooms in organically
          var th = hash(i, j, o.seed + 999) * 0.7 + nx * 0.3
          a *= smooth(th - 0.12, th + 0.12, o.reveal * 1.24 - 0.12)
        }
        if (a <= 0.02) continue
        var r = half * Math.sqrt(a) * 0.98
        if (o.shape === 'pixel') {
          var s = Math.round(r * 2 * 0.9)
          if (s > 0) ctx.rect(Math.round(cx - s / 2), Math.round(cy - s / 2), s, s)
        } else {
          ctx.moveTo(cx + r, cy)
          ctx.arc(cx, cy, r, 0, 6.2832)
        }
      }
    }
    ctx.fill()
  }

  /** Size a canvas for crisp output and return its 2D context (CSS px coordinates). */
  function fit(canvas, width, height, dpr) {
    var ratio = dpr || 1
    canvas.width = Math.round(width * ratio)
    canvas.height = Math.round(height * ratio)
    var ctx = canvas.getContext('2d')
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0)
    return ctx
  }

  root.FOSClouds = { draw: draw, fit: fit, density: density }
})(typeof window !== 'undefined' ? window : globalThis)
