# motion-finance

The Finance OS motion system, packaged as an agent skill.

- **Motion tokens** — durations, easings, distances and stagger, identical across CSS, Framer Motion and GSAP.
- **UI rules** — when an interface should move, and how.
- **A video pipeline** — branded [HyperFrames](https://github.com/heygen-com/hyperframes) compositions (HTML + GSAP → MP4) with real fonts and logos.
- **The signature texture** — Atlas Blue halftone clouds, as code.
- **A calm audit** — a script that fails a film for bouncing, looping, off-palette colour or a fabricated logo.

Live documentation and examples: **https://ds.financeos.au/#motion**

## Install

```bash
git clone https://github.com/teamos-ai/motion-finance.git
ln -s "$(pwd)/motion-finance/skills/motion-finance" ~/.claude/skills/motion-finance
```

Then ask Claude Code for "a Finance OS brand sting", or to "review this page's motion with motion-finance".
For Codex or other agents, point them at `skills/motion-finance/SKILL.md`.

## Make a film

```bash
bash skills/motion-finance/scripts/new-video.sh ./my-film
cd my-film
HYPERFRAMES_NO_TELEMETRY=1 npx hyperframes lint
node ../skills/motion-finance/scripts/calm-audit.mjs .
HYPERFRAMES_NO_TELEMETRY=1 npx hyperframes render --quality looks --output out.mp4
```

Requires Node 22+ and FFmpeg.

## Layout

```
skills/motion-finance/
  SKILL.md               entry point: the five laws, tokens, workflow, hard rules
  references/            tokens · ui-motion · video · patterns · clouds · qa · stack
  kit/                   the scaffold: index.html + assets (fonts, logos, css, motion + cloud js)
  scripts/               new-video.sh · calm-audit.mjs
examples/                four working films + renders/
```

## Examples

| Film | Shows |
| --- | --- |
| `brand-sting` | the cloud dissolve, the lockup landing, land-and-hold |
| `kinetic-headline` | masked lines, one blue keyword, drawn underline, paper clouds |
| `data-story` | count-ups and bars from the baseline — every figure real |
| `flow-diagram` | a five-act diagram build with the one sanctioned confirm |

Re-render all: `for e in examples/*/; do (cd "$e" && npx hyperframes render --output "../renders/$(basename "$e").mp4"); done`

## Updating the kit

`skills/motion-finance/kit/assets` is the source of truth. Each example carries a copy so it renders
standalone; after changing the kit, re-copy it into the examples.

Proprietary — ONESTAAACK A.I PTY LTD. Method credits: `NOTICE.md`.
