# Finance OS — Animated Lucide icon pack

A vendored snapshot of **AnimateIcons** (the animated Lucide set) for use in the
Finance OS design system.

- **Source:** https://github.com/Avijit07x/animateicons
- **Snapshot commit:** `23e58d0fcf4b77f38e303c2dad37624b6f20e15d`
- **Icons:** 999 animated Lucide components (`icons/lucide/*-icon.tsx`)
- **Licence:** MIT (AnimateIcons) + ISC (Lucide base shapes). See `LICENSE` and
  `THIRD_PARTY_NOTICES.md` — keep **both** if you redistribute this pack.

## What's inside
- `icons/lucide/<name>-icon.tsx` — one self-contained component per icon. Each inlines its
  SVG path and its Motion animation variants; exported as PascalCase + `Icon`
  (e.g. `ZapIcon`), with a `*IconHandle` ref exposing `startAnimation()` / `stopAnimation()`.
- `icons/lucide/{index.ts, loaders.ts, meta.ts, summary.ts}` — barrel export + metadata helpers.

## Using one in this project (two small fixes)
Each icon needs the **Motion** runtime and a `cn` helper:

1. **Motion, not framer-motion.** These import from `motion/react` (the `motion` package),
   NOT `framer-motion`. Either `npm i motion` (it coexists with framer-motion), or replace the
   import specifier `motion/react` → `framer-motion` in the files you use — the symbols
   (`m`, `LazyMotion`, `domMin`, `useAnimation`, `useReducedMotion`, `Variants`) all exist in
   framer-motion too.
2. **`cn` path.** They import `{ cn } from "@/lib/utils"`. This repo's `cn` lives at
   `@/lib/cn` — repoint the import, or add a `@/lib/utils` re-export of it.
3. Each file begins with `"use client";` — harmless under Vite/React.

```tsx
import { ZapIcon } from './icons/lucide/zap-icon'
// <ZapIcon size={24} />   — animates on hover by default
```

Props: `size` (24), `duration` (1), `isAnimated` (true), `color`, plus div HTML attributes.

## Note
Static (non-animated) Lucide icons are already available in this project via `lucide-react`
(`import { Zap } from 'lucide-react'`). Use this pack when you want the motion.
