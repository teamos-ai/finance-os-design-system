"use client";

import { cn } from "@/lib/utils";
import type { Variants } from "motion/react";
import {
 LazyMotion,
 domMin,
 m,
 useAnimation,
 useReducedMotion,
} from "motion/react";
import {
 forwardRef,
 useCallback,
 useImperativeHandle,
 useRef,
 type HTMLAttributes,
} from "react";
export interface ArrowDownZAIconHandle {
 startAnimation: () => void;
 stopAnimation: () => void;
}

interface ArrowDownZAIconProps extends Omit<
 HTMLAttributes<HTMLDivElement>,
 | "color"
 | "onDrag"
 | "onDragStart"
 | "onDragEnd"
 | "onAnimationStart"
 | "onAnimationEnd"
 | "onAnimationIteration"
> {
 size?: number;
 duration?: number;
 isAnimated?: boolean;
 color?: string;
}

const ArrowDownZAIcon = forwardRef<ArrowDownZAIconHandle, ArrowDownZAIconProps>(
 (
  {
   onMouseEnter,
   onMouseLeave,
   className,
   size = 24,
   duration = 1,
   isAnimated = true,
   color,
   ...props
  },
  ref,
 ) => {
  const controls = useAnimation();
  const reduced = useReducedMotion();
  const isControlled = useRef(false);

  useImperativeHandle(ref, () => {
   isControlled.current = true;
   return {
    startAnimation: () =>
     reduced ? controls.start("normal") : controls.start("animate"),
    stopAnimation: () => controls.start("normal"),
   };
  });

  const handleEnter = useCallback(
   (e?: React.MouseEvent<HTMLDivElement>) => {
    if (!isAnimated || reduced) return;
    if (!isControlled.current) controls.start("animate");
    else onMouseEnter?.(e as any);
   },
   [controls, reduced, isAnimated, onMouseEnter],
  );

  const handleLeave = useCallback(
   (e?: React.MouseEvent<HTMLDivElement>) => {
    if (!isControlled.current) controls.start("normal");
    else onMouseLeave?.(e as any);
   },
   [controls, onMouseLeave],
  );

  const arrowVariants: Variants = {
   normal: { y: 0 },
   animate: {
    y: [0, 2, -0.5, 0],
    transition: {
     duration: 0.6 * duration,
     ease: "easeInOut",
     times: [0, 0.35, 0.7, 1],
    },
   },
  };

  const swapVariants = (dy: number, dx: number): Variants => ({
   normal: { x: 0, y: 0 },
   animate: {
    y: [0, dy, 0],
    x: [0, dx, 0, dx, 0],
    transition: {
     y: { duration: 0.9 * duration, ease: "easeInOut", times: [0, 0.5, 1] },
     x: {
      duration: 0.9 * duration,
      ease: "easeInOut",
      times: [0, 0.25, 0.5, 0.75, 1],
     },
    },
   },
  });

  return (
   <LazyMotion features={domMin} strict>
    <m.div
     className={cn("inline-flex items-center justify-center", className)}
     onMouseEnter={handleEnter}
     onMouseLeave={handleLeave}
     {...props}
     style={{ color, ...props.style }}
    >
     <m.svg
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      animate={controls}
      initial="normal"
     >
      <m.g variants={arrowVariants}>
       <path d="m3 16 4 4 4-4" />
       <path d="M7 4v16" />
      </m.g>
      <m.path d="M15 4h5l-5 6h5" variants={swapVariants(10, 2.5)} />
      <m.g variants={swapVariants(-10, -2.5)}>
       <path d="M15 20v-3.5a2.5 2.5 0 0 1 5 0V20" />
       <path d="M20 18h-5" />
      </m.g>
     </m.svg>
    </m.div>
   </LazyMotion>
  );
 },
);

ArrowDownZAIcon.displayName = "ArrowDownZAIcon";
export { ArrowDownZAIcon };
