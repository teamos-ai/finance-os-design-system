"use client";

import { cn } from "@/lib/utils";
import type { Variants } from "motion/react";
import {
 LazyMotion,
 domMin,
 m,
 useAnimation,
 useReducedMotion,
} from "motion/react";
import {
 forwardRef,
 useCallback,
 useImperativeHandle,
 useRef,
 type HTMLAttributes,
} from "react";
export interface BatteryMediumIconHandle {
 startAnimation: () => void;
 stopAnimation: () => void;
}

interface BatteryMediumIconProps extends Omit<
 HTMLAttributes<HTMLDivElement>,
 | "color"
 | "onDrag"
 | "onDragStart"
 | "onDragEnd"
 | "onAnimationStart"
 | "onAnimationEnd"
 | "onAnimationIteration"
> {
 size?: number;
 duration?: number;
 isAnimated?: boolean;
 color?: string;
}

const BatteryMediumIcon = forwardRef<
 BatteryMediumIconHandle,
 BatteryMediumIconProps
>(
 (
  {
   onMouseEnter,
   onMouseLeave,
   className,
   size = 24,
   duration = 1,
   isAnimated = true,
   color,
   ...props
  },
  ref,
 ) => {
  const controls = useAnimation();
  const reduced = useReducedMotion();
  const isControlled = useRef(false);

  useImperativeHandle(ref, () => {
   isControlled.current = true;
   return {
    startAnimation: () =>
     reduced ? controls.start("normal") : controls.start("animate"),
    stopAnimation: () => controls.start("normal"),
   };
  });

  const handleEnter = useCallback(
   (e?: React.MouseEvent<HTMLDivElement>) => {
    if (!isAnimated || reduced) return;
    if (!isControlled.current) controls.start("animate");
    else onMouseEnter?.(e as any);
   },
   [controls, reduced, isAnimated, onMouseEnter],
  );

  const handleLeave = useCallback(
   (e?: React.MouseEvent<HTMLDivElement>) => {
    if (!isControlled.current) controls.start("normal");
    else onMouseLeave?.(e as any);
   },
   [controls, onMouseLeave],
  );

  const bodyVariants: Variants = {
   normal: { scaleX: 1 },
   animate: {
    scaleX: [1, 0.92, 1.02, 1],
    transition: {
     duration: 0.6 * duration,
     ease: "easeInOut",
     times: [0, 0.35, 0.7, 1],
    },
   },
  };

  const capVariants: Variants = {
   normal: { x: 0, scaleY: 1 },
   animate: {
    x: [0, -1.3, 0.3, 0],
    scaleY: [1, 1.5, 1, 1],
    transition: {
     duration: 0.6 * duration,
     ease: "easeInOut",
     times: [0, 0.35, 0.7, 1],
    },
   },
  };

  const cellVariants: Variants = {
   normal: { scaleY: 1 },
   animate: {
    scaleY: [1, 0.65, 1.08, 1],
    transition: {
     duration: 0.6 * duration,
     ease: "easeInOut",
     times: [0, 0.35, 0.7, 1],
    },
   },
  };

  return (
   <LazyMotion features={domMin} strict>
    <m.div
     className={cn("inline-flex items-center justify-center", className)}
     onMouseEnter={handleEnter}
     onMouseLeave={handleLeave}
     {...props}
     style={{ color, ...props.style }}
    >
     <m.svg
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      animate={controls}
      initial="normal"
     >
      <m.path
       d="M22 14v-4"
       variants={capVariants}
       style={{ transformBox: "view-box", originX: "22px", originY: "12px" }}
      />
      <m.g
       variants={bodyVariants}
       style={{ transformBox: "view-box", originX: "2px", originY: "12px" }}
      >
       <rect x="2" y="6" width="16" height="12" rx="2" />
       <m.path
        d="M6 14v-4"
        variants={cellVariants}
        style={{ transformBox: "view-box", originX: "6px", originY: "12px" }}
       />
       <m.path
        d="M10 14v-4"
        variants={cellVariants}
        style={{ transformBox: "view-box", originX: "10px", originY: "12px" }}
       />
      </m.g>
     </m.svg>
    </m.div>
   </LazyMotion>
  );
 },
);

BatteryMediumIcon.displayName = "BatteryMediumIcon";
export { BatteryMediumIcon };
