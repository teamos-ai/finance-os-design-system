"use client";

import { cn } from "@/lib/utils";
import type { Variants } from "motion/react";
import {
 LazyMotion,
 domMin,
 m,
 useAnimation,
 useReducedMotion,
} from "motion/react";
import {
 forwardRef,
 useCallback,
 useImperativeHandle,
 useRef,
 type HTMLAttributes,
} from "react";
export interface LockKeyholeOpenIconHandle {
 startAnimation: () => void;
 stopAnimation: () => void;
}

interface LockKeyholeOpenIconProps extends Omit<
 HTMLAttributes<HTMLDivElement>,
 | "color"
 | "onDrag"
 | "onDragStart"
 | "onDragEnd"
 | "onAnimationStart"
 | "onAnimationEnd"
 | "onAnimationIteration"
> {
 size?: number;
 duration?: number;
 isAnimated?: boolean;
 color?: string;
}

const LockKeyholeOpenIcon = forwardRef<
 LockKeyholeOpenIconHandle,
 LockKeyholeOpenIconProps
>(
 (
  {
   onMouseEnter,
   onMouseLeave,
   className,
   size = 24,
   duration = 1,
   isAnimated = true,
   color,
   ...props
  },
  ref,
 ) => {
  const controls = useAnimation();
  const reduced = useReducedMotion();
  const isControlled = useRef(false);

  useImperativeHandle(ref, () => {
   isControlled.current = true;
   return {
    startAnimation: () =>
     reduced ? controls.start("normal") : controls.start("animate"),
    stopAnimation: () => controls.start("normal"),
   };
  });

  const handleEnter = useCallback(
   (e?: React.MouseEvent<HTMLDivElement>) => {
    if (!isAnimated || reduced) return;
    if (!isControlled.current) controls.start("animate");
    else onMouseEnter?.(e as any);
   },
   [controls, reduced, isAnimated, onMouseEnter],
  );

  const handleLeave = useCallback(
   (e?: React.MouseEvent<HTMLDivElement>) => {
    if (!isControlled.current) controls.start("normal");
    else onMouseLeave?.(e as any);
   },
   [controls, onMouseLeave],
  );

  const shackleVariants: Variants = {
   normal: { rotate: 0 },
   animate: {
    rotate: [0, -14, 5, -2, 0],
    transition: {
     duration: 0.7 * duration,
     ease: "easeInOut",
     times: [0, 0.35, 0.65, 0.85, 1],
    },
   },
  };

  const bodyVariants: Variants = {
   normal: { y: 0 },
   animate: {
    y: [0, 0.8, 0],
    transition: { duration: 0.35 * duration, ease: "easeOut" },
   },
  };

  const holeVariants: Variants = {
   normal: { scale: 1 },
   animate: {
    scale: [1, 1.5, 1],
    transition: {
     duration: 0.4 * duration,
     ease: "easeInOut",
     delay: 0.15 * duration,
    },
   },
  };

  return (
   <LazyMotion features={domMin} strict>
    <m.div
     className={cn("inline-flex items-center justify-center", className)}
     onMouseEnter={handleEnter}
     onMouseLeave={handleLeave}
     {...props}
     style={{ color, ...props.style }}
    >
     <m.svg
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      animate={controls}
      initial="normal"
     >
      <m.g variants={bodyVariants}>
       <m.circle
        cx="12"
        cy="16"
        r="1"
        variants={holeVariants}
        style={{ transformBox: "view-box", originX: "12px", originY: "16px" }}
       />
       <rect width="18" height="12" x="3" y="10" rx="2" />
      </m.g>
      <m.path
       d="M7 10V7a5 5 0 0 1 9.33-2.5"
       variants={shackleVariants}
       style={{ transformBox: "view-box", originX: "7px", originY: "10px" }}
      />
     </m.svg>
    </m.div>
   </LazyMotion>
  );
 },
);

LockKeyholeOpenIcon.displayName = "LockKeyholeOpenIcon";
export { LockKeyholeOpenIcon };
