"use client";

import { cn } from "@/lib/utils";
import type { Variants } from "motion/react";
import {
 LazyMotion,
 domMin,
 m,
 useAnimation,
 useReducedMotion,
} from "motion/react";
import {
 forwardRef,
 useCallback,
 useImperativeHandle,
 useRef,
 type HTMLAttributes,
} from "react";
export interface AudioLinesXIconHandle {
 startAnimation: () => void;
 stopAnimation: () => void;
}

interface AudioLinesXIconProps extends Omit<
 HTMLAttributes<HTMLDivElement>,
 | "color"
 | "onDrag"
 | "onDragStart"
 | "onDragEnd"
 | "onAnimationStart"
 | "onAnimationEnd"
 | "onAnimationIteration"
> {
 size?: number;
 duration?: number;
 isAnimated?: boolean;
 color?: string;
}

const AudioLinesXIcon = forwardRef<AudioLinesXIconHandle, AudioLinesXIconProps>(
 (
  {
   onMouseEnter,
   onMouseLeave,
   className,
   size = 24,
   duration = 1,
   isAnimated = true,
   color,
   ...props
  },
  ref,
 ) => {
  const controls = useAnimation();
  const reduced = useReducedMotion();
  const isControlled = useRef(false);

  useImperativeHandle(ref, () => {
   isControlled.current = true;
   return {
    startAnimation: () =>
     reduced ? controls.start("normal") : controls.start("animate"),
    stopAnimation: () => controls.start("normal"),
   };
  });

  const handleEnter = useCallback(
   (e?: React.MouseEvent<HTMLDivElement>) => {
    if (!isAnimated || reduced) return;
    if (!isControlled.current) controls.start("animate");
    else onMouseEnter?.(e as any);
   },
   [controls, reduced, isAnimated, onMouseEnter],
  );

  const handleLeave = useCallback(
   (e?: React.MouseEvent<HTMLDivElement>) => {
    if (!isControlled.current) controls.start("normal");
    else onMouseLeave?.(e as any);
   },
   [controls, onMouseLeave],
  );

  const barVariants = (scale: number, delay: number): Variants => ({
   normal: { scaleY: 1 },
   animate: {
    scaleY: [1, scale, 1],
    transition: {
     duration: 0.6 * duration,
     ease: "easeInOut",
     delay: delay * duration,
    },
   },
  });

  const crossVariants: Variants = {
   normal: { rotate: 0, scale: 1, transition: { duration: 0 } },
   animate: {
    rotate: [0, 90],
    scale: [1, 1.2, 1],
    transition: { duration: 0.5 * duration, ease: "easeInOut" },
   },
  };

  return (
   <LazyMotion features={domMin} strict>
    <m.div
     className={cn("inline-flex items-center justify-center", className)}
     onMouseEnter={handleEnter}
     onMouseLeave={handleLeave}
     {...props}
     style={{ color, ...props.style }}
    >
     <m.svg
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      animate={controls}
      initial="normal"
     >
      <m.path
       d="M2 10v3"
       variants={barVariants(2.4, 0)}
       style={{ transformBox: "view-box", originX: "2px", originY: "11.5px" }}
      />
      <m.path
       d="M6 6v11"
       variants={barVariants(0.55, 0.05)}
       style={{ transformBox: "view-box", originX: "6px", originY: "11.5px" }}
      />
      <m.path
       d="M10 3v18"
       variants={barVariants(0.55, 0.1)}
       style={{ transformBox: "view-box", originX: "10px", originY: "12px" }}
      />
      <m.path
       d="M14 8v6.35"
       variants={barVariants(1.7, 0.15)}
       style={{ transformBox: "view-box", originX: "14px", originY: "11.5px" }}
      />
      <m.path
       d="M18 5v8.1"
       variants={barVariants(0.6, 0.2)}
       style={{ transformBox: "view-box", originX: "18px", originY: "11.5px" }}
      />
      <m.path
       d="M22 10v3"
       variants={barVariants(2.4, 0.25)}
       style={{ transformBox: "view-box", originX: "22px", originY: "11.5px" }}
      />
      <m.g
       variants={crossVariants}
       style={{
        transformBox: "view-box",
        originX: "19.5px",
        originY: "19.5px",
       }}
      >
       <path d="m17 17 5 5" />
       <path d="m22 17-5 5" />
      </m.g>
     </m.svg>
    </m.div>
   </LazyMotion>
  );
 },
);

AudioLinesXIcon.displayName = "AudioLinesXIcon";
export { AudioLinesXIcon };
