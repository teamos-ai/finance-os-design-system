"use client";

import { cn } from "@/lib/utils";
import type { Variants } from "motion/react";
import {
 LazyMotion,
 domMin,
 m,
 useAnimation,
 useReducedMotion,
} from "motion/react";
import {
 forwardRef,
 useCallback,
 useImperativeHandle,
 useRef,
 type HTMLAttributes,
} from "react";
export interface HouseWifiIconHandle {
 startAnimation: () => void;
 stopAnimation: () => void;
}

interface HouseWifiIconProps extends Omit<
 HTMLAttributes<HTMLDivElement>,
 | "color"
 | "onDrag"
 | "onDragStart"
 | "onDragEnd"
 | "onAnimationStart"
 | "onAnimationEnd"
 | "onAnimationIteration"
> {
 size?: number;
 duration?: number;
 isAnimated?: boolean;
 color?: string;
}

const HouseWifiIcon = forwardRef<HouseWifiIconHandle, HouseWifiIconProps>(
 (
  {
   onMouseEnter,
   onMouseLeave,
   className,
   size = 24,
   duration = 1,
   isAnimated = true,
   color,
   ...props
  },
  ref,
 ) => {
  const controls = useAnimation();
  const reduced = useReducedMotion();
  const isControlled = useRef(false);

  useImperativeHandle(ref, () => {
   isControlled.current = true;
   return {
    startAnimation: () =>
     reduced ? controls.start("normal") : controls.start("animate"),
    stopAnimation: () => controls.start("normal"),
   };
  });

  const handleEnter = useCallback(
   (e?: React.MouseEvent<HTMLDivElement>) => {
    if (!isAnimated || reduced) return;
    if (!isControlled.current) controls.start("animate");
    else onMouseEnter?.(e as any);
   },
   [controls, reduced, isAnimated, onMouseEnter],
  );

  const handleLeave = useCallback(
   (e?: React.MouseEvent<HTMLDivElement>) => {
    if (!isControlled.current) controls.start("normal");
    else onMouseLeave?.(e as any);
   },
   [controls, onMouseLeave],
  );

  const houseVariants: Variants = {
   normal: { scale: 1 },
   animate: {
    scale: [1, 0.8, 1.06, 1],
    transition: {
     duration: 0.7 * duration,
     ease: "easeInOut",
     times: [0, 0.35, 0.75, 1],
    },
   },
  };

  const dotVariants: Variants = {
   normal: { scale: 1 },
   animate: {
    scale: [1, 1.7, 1],
    transition: { duration: 0.4 * duration, ease: "easeInOut" },
   },
  };

  const arcVariants: Variants = {
   normal: { y: 0 },
   animate: (i: number) => ({
    y: [0, -1.5, 0.4, 0],
    transition: {
     duration: 0.6 * duration,
     ease: "easeInOut",
     times: [0, 0.35, 0.7, 1],
     delay: (0.1 + i * 0.08) * duration,
    },
   }),
  };

  return (
   <LazyMotion features={domMin} strict>
    <m.div
     className={cn("inline-flex items-center justify-center", className)}
     onMouseEnter={handleEnter}
     onMouseLeave={handleLeave}
     {...props}
     style={{ color, ...props.style }}
    >
     <m.svg
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      animate={controls}
      initial="normal"
     >
      <m.g
       variants={houseVariants}
       style={{ transformBox: "view-box", originX: "12px", originY: "21px" }}
      >
       <m.path
        d="M9.5 13.866a4 4 0 0 1 5 .01"
        variants={arcVariants}
        custom={0}
       />
       <m.path
        d="M12 17h.01"
        variants={dotVariants}
        style={{ transformBox: "view-box", originX: "12px", originY: "17px" }}
       />
       <path d="M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
       <m.path d="M7 10.754a8 8 0 0 1 10 0" variants={arcVariants} custom={1} />
      </m.g>
     </m.svg>
    </m.div>
   </LazyMotion>
  );
 },
);

HouseWifiIcon.displayName = "HouseWifiIcon";
export { HouseWifiIcon };
